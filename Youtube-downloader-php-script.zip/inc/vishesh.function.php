<?php
error_reporting(0);
$uri = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$site = $_SERVER['HTTP_HOST'];
$sitename = 'GBYouTube';

$keywords = 'download youtube videos, download video gratis, download lagu gratis, download mp3 gratis';
$description = 'download gratis, download video gratis, download lagu gratis, download mp3 gratis';

$key = 'AIzaSyCzyoQwI_Ap7XJhBO1i4bPNqyrI1BdRs70';

function get($url) {
$data=get_headers($url, true);
return $data[Location][0];
}
function get_location($url) {
$data=get_headers($url, true);
if (isset($data['Location']))
return $data['Location'];
}
function get_name($url) {
$data=get_headers($url, true);
$arfi = cut($data['Content-Disposition'], '"','"');
if (isset($arfi))
return $arfi;
}
function get_size($url) {
$data=get_headers($url, true);
if (isset($data['Content-Length']))
return $data['Content-Length'];
}
function get_type($url) {
$data=get_headers($url, true);
if (isset($data['Content-Type']))
return $data['Content-Type'];
}

function f3($url){
    $curl = curl_init();
    $header[0] = "Accept: text/xml,application/xml,application/xhtml+xml,";
    $header[0] .= "text/html, application/xml;q=0.9, application/xhtml+xml, image/png, image/webp, image/jpeg, image/gif, image/x-xbitmap, */*;q=0.1";
    $header[] = "Cache-Control: max-age=0";
    $header[] = "Connection: keep-alive";
    $header[] = "Keep-Alive: 300";
    $header[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $header[] = "Accept-Language: in-ID,in;q=0.9";
    $header[] = "Pragma: ";
    $referer = "http://www.youtube.com/";
    $btext = rand(0,100000);
   $browser = 'Opera/9.80 (Series 60; Opera Mini/7.1.32444/37.9093; U; en) Presto/2.12.423 Version/12.16' . $btext;
 
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_USERAGENT, $browser);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
    curl_setopt($curl, CURLOPT_REFERER, $referer);
    curl_setopt($curl, CURLOPT_AUTOREFERER, true);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 60);
    curl_setopt($curl, CURLOPT_MAXREDIRS, 14);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, false);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
return curl_exec($curl);
    curl_close($curl);
}
function arfi($url){
    if (!function_exists("curl_init")) {
		$f = file_get_contents($url);
	} else {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20);
		curl_setopt($ch, CURLOPT_REFERER, 'http://www.youtube.com/');
		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/534.30 (KHTML, like Gecko) Chrome/12.0.742.91 Safari/534.30");
		$f = curl_exec($ch);
		curl_close($ch);
	}
   return $f;  
}

function arjo($url){
$ch = curl_init(); curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($ch,CURLOPT_ENCODING,'gzip');
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
$header[] = "Accept-Language: en";
$header[] = "User-Agent: Mozilla/5.0 (Windows; U; Windows NT 6.3) Gecko/20100401 Firefox/43.6.3";
$header[] = "Pragma: no-cache";
$header[] = "Cache-Control: no-cache";
$header[] = "Accept-Encoding: gzip,deflate";
$header[] = "Content-Encoding: gzip";
$header[] = "Content-Encoding: deflate";
curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
$load = curl_exec($ch);
curl_close($ch);
return $load;
}
if(file_exists('error_log')){
unlink('error_log');
}

function formatBytes($bytes, $precision = 2) { 
    $units = array('B', 'kB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'); 
    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow]; 
} 

function cut($content,$start,$end){
if($content && $start && $end) {
$r = explode($start, $content);
if (isset($r[1])){
$r = explode($end, $r[1]);
return $r[0];}
return '';}}

function format_timeyt($t) 
{
$hasil = str_replace('PT','',$t);
$hasil = str_replace('H','h ',$hasil);
$hasil = str_replace('M','m ',$hasil);
$hasil = str_replace('S','s',$hasil);
return $hasil;
}
function dateyt($date)
{
$date = substr($date,0,10); 
$date = explode('-',$date);
$mn   = date('F',mktime(0,0,0,$date[1])); 
$dates= ''.$date[2].' '.$mn.' '.$date[0].''; 
return $dates;
}

function timeyt($t) 
{
$hasil = str_replace('PT','',$t);
$hasil = str_replace('H','hour : ',$hasil);
$hasil = str_replace('M','minutes : ',$hasil);
$hasil = str_replace('S','second ',$hasil);
return $hasil;
}
?>