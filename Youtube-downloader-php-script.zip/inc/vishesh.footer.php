<div class="biru2"><h2><i class="fa fa-search" aria-hidden="true"></i> Recent Search</h2></div>

<div class="mennu" style="margin-bottom:0px;padding:6px;border: 1px solid #333;text-align:justify;">
<?php
$div = "|#|";
$dat='lastsearch.txt';

$fa=fopen($dat, 'r');
$b=fgets($fa);
fclose($fa);
$c = explode($div, $b);

foreach(array_reverse($c) as $d){
echo '<a title="'.$d.'" href="//'.$site.'/telusur.php?q='.str_replace(' ', '+', $d).'">'.$d.'</a> &bull; ';

}
?>
</div>
<script type="text/javascript" src="http://wap4dollar.com/ad/code/?id=pkfenmxmgz"></script><script type="text/javascript" src="http://wap4dollar.com/ad/codex/?id=pkfenmxmgz"></script>
<div class="headerbottom">
<strong>&copy; <?echo date("Y");echo' ';echo $sitename;?></strong>
</div>
</body></html>