<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?echo $title;?></title>
<meta charset="utf-8">
<meta name="spiders" content="all" />
<meta name="googlebot" content="All, index, follow" />
<meta name="robots" content="All, index, follow" />
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-3064581769346361",
    enable_page_level_ads: true
  });
</script>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-3064581769346361",
          enable_page_level_ads: true
     });
</script>
<meta name="google-site-verification" content="Ky5MjpjQl6n3Px6Hs9Nd3xChofNzBhSkWn9AV0Vp720" />
<meta name="google-site-verification" content="Ky5MjpjQl6n3Px6Hs9Nd3xChofNzBhSkWn9AV0Vp720" />
<meta name="google-site-verification" content="lfeWdRTPYLCpNwYy_5_M7iLlEnDYu1CBStLSXtlClNo" />
<!--[if IE]><meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"><![endif]-->
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="keyword" content="<?echo $keywords;?>" gbyoutube, gbyoutube.cf, gbyoutube world, download youtube , mp3 youtube gbyoutube, video, sharing, camera phone, video phone, free, upload />
<meta name="description" content="<?echo $description;?>" Enjoy the videos and music you love, upload original content, and share it all with friends, family, and the world on YouTube />

<link rel="shortcut icon" href="https://www.youtube.com/favicon.ico" type="image/x-icon"/>
<?php
if(isset($_GET['v']) && !empty($_GET['v'])) {
echo '
<meta property="og:image" content="http://'.$site.'/ytimg/vi/'.$_GET['v'].'/hqdefault.jpg" />
';
}else{
echo '
<meta property="og:image" content="http://'.$site.'/img/thumb.jpg" />
';
}
?>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-7810839517552825",
    enable_page_level_ads: true
  });
</script><link href='https://fonts.googleapis.com/css?family=Cuprum' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">
<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1/themes/blitzer/jquery-ui.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" type="text/css" href="//<?echo $site;?>/css/style.css">
<style>
.headertop { background-color: red; border:none; color:#292929; height:39px; padding:0; line-height: 39px; border-bottom: solid 3px #E4A915; font-weight: bold; } 
.headerbottom { background-color: #797979; border:none; color:#fff; height:35px; padding:0; line-height: 35px; border-bottom: solid 2px red; text-align: center; } .djnew { margin: 1; } .style19 {color: #FF0000} .style20 { font-size: 12px } .style21 { color: #FF3300; font-weight: bold; } .black { color: #030303; } .red { color: #CC0000; font-weight: bolder; }
.margin { margin: 0; } .google_search { min-height: 100px; } .google_search2 { min-height: 60px; width:100%; } .google_search2 form { padding: 17px; padding-left: 0; } .google_search2 input[type=text] { width: 70%; max-width:300px; padding: 7px; border-radius: 9px; border: 2px solid #eee; } .google_search2 input[type=submit] { width: 10%; padding: 6px; background: #2288ee none repeat scroll 0 0; border: 1px solid #0063c9; font-size: 14px; border-radius: 9px; color: #fff; box-shadow: 1px 2px 5px #003; min-width: 60px; cursor: pointer; }
.vheader { padding:7px; background:#3399FF; repeat-x; color:#F5F5F5; border:1px solid #595959; font-weight:bold; margin-top:1px; } 
</style>

</head><body>
<div class="headertop">

<a href="//<?echo $site;?>/"><i class="	fa fa-youtube-play"></i> <?echo $sitename;?>
</a>
</div>
</div>
<br/>
<br/>
<div class='google_search2'><form id='form' method='get' action='//<?echo $site;?>/vishesh.grewal.php'>
<input id='inputs' type='text' class='search_input' placeholder='' name='q' value='' style='padding-left: 4px;'>
<input type='submit' class='search_submit' value='Search'>
</form><script src='http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js' type='text/javascript'></script>
<script src='http://ajax.googleapis.com/ajax/libs/jqueryui/1/jquery-ui.min.js' type='text/javascript'></script>
<script>

jQuery(document).ready(function() {
$.fn.googleSuggest = function(opts){
  opts = $.extend({service: 'youtube', secure: false}, opts);

  var services = {
    youtube: { client: 'youtube', ds: 'yt' },
    books: { client: 'books', ds: 'bo' },
    products: { client: 'products-cc', ds: 'sh' },
    news: { client: 'news-cc', ds: 'n' },
    images: { client: 'img', ds: 'i' },
    web: { client: 'psy', ds: '' },
    recipes: { client: 'psy', ds: 'r' }
  }, service = services[opts.service];

  opts.source = function(request, response){
    $.ajax({
      url: 'http'+(opts.secure?'s':'')+'://clients1.google.com/complete/search',      dataType: 'jsonp',
      data: {
        q: request.term,
        nolabels: 't',
        client: service.client,
        ds: service.ds      },      success: function(data) {        response($.map(data[1], function(item){          return { value: $('<span>').html(item[0]).text() };
        }));
      }
    });  
  };

    opts.select = function(event,ui){
      $('#inputs').val(ui.item.label);
      $('#form').submit();
      
      };
  
  return this.each(function(){
    $(this).autocomplete(opts);
  });
}

$('#inputs').googleSuggest();

});

</script>
<?php            echo '<script src="//'.$site.'/js/twinput1.0.0.js"></script>
        <script>
        $(\'.search_input\').tw_input_placeholder({
            speed: 100,
            delay: 2000,
            keywords: [\'Hello!\', \'';
if(isset($_GET['q']) && !empty($_GET['q'])) {
echo 'Your search \"'.$_GET['q'].'\"';
}else if(isset($_GET['v']) && !empty($_GET['v'])) {
echo 'Your watch \"'.ucwords($name).'\"';
}else if(!isset($_GET['v'])=='') {
echo 'Your watch \"'.ucwords('NoID').'\"';
}else {
echo 'What do you want to find..?';
}
echo '\']
        });
        </script><script type="text/javascript" src="http://wap4dollar.com/ad/pops/?id=pkfenmxmgz"></script>
<script type="text/javascript" src="http://wap4dollar.com/ad/code/?id=pkfenmxmgz"></script>';
?>

</div>

