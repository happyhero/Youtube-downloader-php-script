<?php
$my_id = $_GET["v"];
include 'inc/vishesh.function.php';

if(isset($_REQUEST['v'])) {
   $my_id = $_REQUEST['v'];
   if( preg_match('/^(https?:\/\/)?(w{3}\.)?(m?\.)?youtube.com\//', $my_id) ){
      $url   = parse_url($my_id);
      $my_id = NULL;
      if( is_array($url) && count($url)>0 && isset($url['query']) && !empty($url['query']) ){
         $parts = explode('&',$url['query']);
         if( is_array($parts) && count($parts) > 0 ){
            foreach( $parts as $p ){
               $pattern = '/^v\=/';
               if( preg_match($pattern, $p) ){
                  $my_id = preg_replace($pattern,'',$p);
                  break;
               }
            }
         }
         if( !$my_id ){
            echo '<p>No video id passed in</p>';
            exit;
         }
      }else{
         echo '<p>Invalid url</p>';
         exit;
      }
   }elseif( preg_match('/^(https?:\/\/)?youtu.be/', $my_id) ) {
      $url   = parse_url($my_id);
      $my_id = NULL;
      $my_id = preg_replace('/^(youtu\.be)?\//', '', $url['path']);
   }
} else {
    echo '<p>No video id passed in</p>';
    exit;
}

      $ar = "http://i1.ytimg.com/vi/$my_id/mqdefault.jpg";
      $file_headers = @get_headers($ar);
if(!$file_headers || $file_headers[0] == 'HTTP/1.0 404 Not Found') {
      $jo = 'http://i1.ytimg.com/vi/arjo/mqdefault.jpg';
} else {
      $jo = $my_id;
}

if (!empty($_GET['v'])=='') {
    echo 'error';
    exit;
} else{
if (!empty($_GET['image'])) {
    switch ($_GET['image']) {
        case 'hqdefault':
$thumbnail = "http://i1.ytimg.com/vi/$jo/hqdefault.jpg";
header("Content-Type: image/jpeg");
header("Content-Type: image/jpg");
readfile($thumbnail);
            break;
        case 'mqdefault':
$thumbnail = "http://i1.ytimg.com/vi/$jo/mqdefault.jpg";
header("Content-Type: image/jpeg");
header("Content-Type: image/jpg");
readfile($thumbnail);
            break;
        case 'default':
$thumbnail = "http://i1.ytimg.com/vi/$jo/default.jpg";
header("Content-Type: image/jpeg");
header("Content-Type: image/jpg");
readfile($thumbnail);
            break;
        case '0':
$thumbnail = "http://i1.ytimg.com/vi/$jo/0.jpg";
header("Content-Type: image/jpeg");
header("Content-Type: image/jpg");
readfile($thumbnail);
            break;
        case '1':
$thumbnail = "http://i1.ytimg.com/vi/$jo/1.jpg";
header("Content-Type: image/jpeg");
header("Content-Type: image/jpg");
readfile($thumbnail);
            break;
        case '2':
$thumbnail = "http://i1.ytimg.com/vi/$jo/2.jpg";
header("Content-Type: image/jpeg");
header("Content-Type: image/jpg");
readfile($thumbnail);
            break;
        case '3':
$thumbnail = "http://i1.ytimg.com/vi/$jo/3.jpg";
header("Content-Type: image/jpeg");
header("Content-Type: image/jpg");
readfile($thumbnail);
            break;
        case 'photo':
$set = json_decode(arjo('https://www.googleapis.com/youtube/v3/channels?part=id,snippet,contentDetails,statistics&key='.$key.'&id='.$cid.''), true);
            $poto = $set['items'][0]['snippet']['thumbnails']['default']['url'];
header("Content-Type: image/jpeg");
header("Content-Type: image/jpg");
readfile($poto);
           break;

        default:
          echo 'Index Of';
            break;
    }
  }else{
    echo 'error';
    exit;
  }
}
?>