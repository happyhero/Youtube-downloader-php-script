<!DOCTYPE html>
<html>
  <head>
    <meta http-equiv="Content-type" content="text/html; charset=utf-8">
    <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; img-src data:; connect-src 'self'">
    <title>Page not found</title>
    <style type="text/css" media="screen">
      body {
        background-color: #f1f1f1;
        margin: 0;
        font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
      }
      .container { margin: 50px auto 40px auto; width: 600px; text-align: center; }
	 </style>
  </head>
  <body>
    <div class="container">
      <h1>404</h1>
      <p><strong>File not found</strong></p>
      <p>
        The site configured at this address does not
        contain the requested file.
      </p>Script Developed  by:- <a href="http://Vishesh.cf">Vishesh Grewal</a>
    </div>
  </body>
</html>