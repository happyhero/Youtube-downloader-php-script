<?php
$cid = $_GET['cid'];
include 'inc/vishesh.function.php';

$token = $_GET['p'];

if(!empty($_GET['limit']) == '') {
$limit = '10';
}else{
$limit = isset($_GET['limit']) ? $_GET['limit']:'10';
}
$set = json_decode(arjo('https://www.googleapis.com/youtube/v3/search?part=id,snippet&order=relevance&regionCode=id&order=date&type=videos&maxResults='.$limit.'&key='.$key.'&channelId='.$cid.'&pageToken='.$token), true);
$channel = $set[items][0][snippet][channelTitle];
$total = $set[pageInfo][totalResults];
if($_GET['cid'] == '') {
$title = ':: '.$sitename.' :: Error Not ChannelID';
$result = 'Error Not ChannelID';
}
else if(!empty($total) == '0') {
$title = ':: '.$sitename.' :: Error ChannelID';
$result = 'Error ChannelID';
} else {
$title = ''.$sitename.' :: Channels '.ucwords($channel).'';
$result = 'All Videos by '.ucwords($channel).' ('.number_format($total).' Videos)';
}
include 'inc/vishesh.header.php';

if($_GET['cid'] == '') {
echo '
<div class="menu2">
<table class="otable" width="100%">
<tbody>
<tr>
<td valign="middle" width="75px" align="center">
<div class="imahe">Error</div></td><td style="padding: 4px 6px 4px 6px;><span style=" font-size: 13px;">An error occurred: </span><span style="font-size: 11px;">sorry, channel id not found.</span></td></tr></tbody></table></div>
';
}
else if(!empty($total) == '0') {
echo '
<div class="menu2">
<table class="otable" width="100%">
<tbody>
<tr>
<td valign="middle" width="75px" align="center">
<div class="imahe">Error</div></td><td style="padding: 4px 6px 4px 6px;><span style=" font-size: 13px;">An error occurred: </span><span style="font-size: 11px;">sorry, error channel id.</span></td></tr></tbody></table></div>
';
}else{
$setSatu = json_decode(arjo('https://www.googleapis.com/youtube/v3/channels?part=id,snippet,contentDetails,statistics&key='.$key.'&id='.$cid.''), true);
$channelSatu = $setSatu[items][0][snippet][title];
$totalSatu = $setSatu[pageInfo][totalResults];
if($_GET['cid'] == '') {
$resultSatu = 'Error Not ChannelID';
}
else if(!empty($totalSatu) == '0') {
$resultSatu = 'Error ChannelID';
} else {
$resultSatu = 'Details Channel '.ucwords($channelSatu).'';
}
echo '
<div class="biru" style="text-align: left;"><h1><i class="fa fa-th-large"></i> '.$resultSatu.'</h1></div><div class=menu align=left><div style="display:" class="breadcrumb">
<span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
<a href="/" itemprop="url"><span itemprop="title">Home</span></a></span> &#9656 <span class="active">'.ucwords($channelSatu).'</span></div></div>
';
foreach($setSatu[items] as $dataSatu){
$olehidSatu = $dataSatu[id];
$olehSatu = $dataSatu[snippet][title];
$descriptSatu = $dataSatu[snippet][description];
$tglSatu = dateyt($dataSatu[snippet][publishedAt]);
$thumbSatu = $dataSatu[snippet][thumbnails][medium][url];
$likes = $dataSatu[contentDetails][relatedPlaylists][likes];
$uploads = $dataSatu[contentDetails][relatedPlaylists][uploads];
$viewSatu = number_format($dataSatu[statistics][viewCount]);
$comment = number_format($dataSatu[statistics][commentCount]);
$subscriber = number_format($dataSatu[statistics][subscriberCount]);
$videoC = number_format($dataSatu[statistics][videoCount]);
echo '
<div class="menu2" style="margin-bottom:0px; text-align: center; background-color: #303030;">
<table style="width:100%;text-align:center;"><tbody style="max-height:100%;"><tr valign="top"><td width="100%"><img src="'.$thumbSatu.'" alt="'.$olehSatu.'"/></td></tr></tbody></table>
</div>
<div class="menu2"><div class="ml"><table class="otable" style="width:100%"><tbody><tr valign="top"> <td width="30%"> Name</td><td> :</td> <td>'.$olehSatu.'</td></tr>
<tr valign="top"><td width="30%"> Views</td><td> : </td> <td> '.$viewSatu.' </td></tr>
<tr valign="top"><td width="30%"> Comment</td><td> : </td> <td> '.$comment.' </td></tr>
<tr valign="top"><td width="30%"> Subscriber</td><td> : </td> <td> '.$subscriber.' </td></tr>
<tr valign="top"><td width="30%"> Video Count</td><td> : </td> <td> '.$videoC.'</td></tr>
<tr valign="top"><td width="30%"> Subscriber</td><td> : </td> <td> '.$subscriber.'</td></tr>
<tr valign="top"><td width="30%"> Merge At</td><td> : </td> <td> '.$tglSatu.'</td></tr>
<tr valign="top"><td width="30%"> Related Playlists</td><td> : </td> <td>';
if($uploads){
echo '<a href="//'.$site.'/playlists?cid='.$uploads.'">Uploads</a>';
}elseif($likes){
echo ' ¤ <a href="//'.$site.'/playlists?cid='.$likes.'">Likes</a>';
}
echo '</td></tr>
<tr valign="top"><td width="30%">Uploaded By</td><td> : </td> <td> '.$olehSatu.'</td></tr>
<tr valign="top"><td width="30%">Description</td><td> : </td> <td> ';
if($descriptSatu == ''){
echo "0";
}else{
echo str_replace(urldecode('%0A'), '<br />', $descriptSatu);
}
echo ' </td></tr></tbody></table></div></div>
</div>
';
}
echo '
<div class="biru" style="text-align: left;"><h1><i class="fa fa-th-large"></i> '.$result.'</h1></div>
';
foreach($set[items] as $data){
$id = $data[id][videoId];
$olehid = $data[snippet][channelId];
$oleh = $data[snippet][channelTitle];
$tgl = dateyt($data[snippet][publishedAt]);
$judul = $data[snippet][title];

$dt = json_decode(arjo('https://www.googleapis.com/youtube/v3/videos?key='.$key.'&part=contentDetails,statistics&id='.$id), true);
foreach ($dt[items] as $dta) {
$watu = $dta[contentDetails][duration];
$durasi = format_timeyt($watu);
$view = number_format($dta[statistics][viewCount]);
$like = number_format($dta[statistics][likeCount]);
$galike = number_format($dta[statistics][dislikeCount]);
}
echo '
<div class="menu2">
<table class="otable" width="100%">
<tbody>
<tr>
<td valign="middle" width="75px" align="center">
<div class="imahe"><img src="//'.$site.'/ytimg/vi/'.$id.'/mqdefault.jpg" alt="'.$judul.'" title="'.$judul.'" style="border: 1px solid #222; border-radius: 2px; float: left;" width="95" height="60"><h8><span>'.$durasi.'</span></h8></div></td><td style="padding: 4px 6px 4px 6px;><span style=" font-size: 13px;"><a href="//'.$site.'/watch?v='.$id.'" title="'.$judul.'">'.$judul.'</a></span><br /><span style="font-size: 11px;"><i class="fa fa-eye" aria-hidden="true" style="color: #ccc;"></i> '.$view.'<br /><i class="fa fa-calendar" aria-hidden="true" style="color: #ddd;"></i> '.$tgl.'<br /><i class="fa fa-users" aria-hidden="true" style="color: #ddd;"></i> <a href="//'.$site.'/channel?cid='.$olehid.'" title="'.$judul.'">'.$oleh.'</a></span></td></tr></tbody></table></div>
';
}
echo '
<div class="result"></div>
<div class="nav" style="text-align:center;">
<div class="show_channel" id="'.$cid.'"></div>
<div class="loading" style="display: none;"><img src="//'.$site.'/img/load.gif"/><br>Loading...</div>
<button class="show_more" id="'.$set[nextPageToken].'" style="text-align:center;margin-top:8px;cursor:pointer;background: #e9e9e9;padding:4px;color:#555;border:1px solid grey;border-radius: 2px">Show more</button>
</div>
';?>
<script type="text/javascript">
$(document).ready(function(){
$(document).on('click','.show_more',function(){
var C = $('.show_channel').attr('id');
var P = $('.show_more').attr('id');
$('.show_more').hide();
$('.loading').show();

$.ajax({	 type:'POST',	 url:'cajax.php', data:'cid='+C+'&p='+P,	 success:function(html){
$('.nav').remove();
$('#'+P).remove();
$('.loading').remove();
$('.result').append(html);
}
});	});});
</script>
</div>
<?php
}
include 'inc/vishesh.footer.php';

?>