<?php
if(!empty($_GET['limit']) == '') {
$limit = '10';
}else{
$limit = isset($_GET['limit']) ? $_GET['limit']:'10';
}
$set = json_decode(arjo('https://www.googleapis.com/youtube/v3/search?part=id,snippet&order=relevance&regionCode=id&q='.urlencode($name).'&type=video&maxResults='.$limit.'&key='.$key.'&relatedToVideoId='.$id), true);
$total = $set[pageInfo][totalResults];
$result = 'Related Videos ('.number_format($total).' Videos)';

echo '
<div class="biru2"><h2><i class="fa fa-bookmark" aria-hidden="true-o"></i> '.$result.'</h2></div>
';

if(!empty($total) == '0') {
echo '
<div class="menu2">
<table class="otable" width="100%">
<tbody>
<tr>
<td valign="middle" width="75px" align="center">
<div class="imahe">Error</div></td><td style="padding: 4px 6px 4px 6px;><span style=" font-size: 13px;">An error occurred: </span><span style="font-size: 11px;">sorry, related not respon.</span></td></tr></tbody></table></div>
';
}else{
foreach($set[items] as $data){
$id = $data[id][videoId];
$olehid = $data[snippet][channelId];
$oleh = $data[snippet][channelTitle];
$tgl = dateyt($data[snippet][publishedAt]);
$judul = $data[snippet][title];
$thumb = $data[snippet][thumbnails][medium][url];

$dt = json_decode(arjo('https://www.googleapis.com/youtube/v3/videos?key='.$key.'&part=contentDetails,statistics&id='.$id), true);
foreach ($dt[items] as $dta) {
$watu = $dta[contentDetails][duration];
$durasi = format_timeyt($watu);
$view = number_format($dta[statistics][viewCount]);
$like = number_format($dta[statistics][likeCount]);
$galike = number_format($dta[statistics][dislikeCount]);
}
$channelId = $data[id][channelId];
if($channelId == '') {
echo '
<div class="menu2">
<table class="otable" width="100%">
<tbody>
<tr>
<td valign="middle" width="75px" align="center">
<div class="imahe"><img src="//'.$site.'/ytimg/vi/'.$id.'/mqdefault.jpg" alt="'.$judul.'" title="'.$judul.'" style="border: 1px solid #222; border-radius: 2px; float: left;" width="95" height="60"><h8><span>'.$durasi.'</span></h8></div></td><td style="padding: 4px 6px 4px 6px;><span style=" font-size: 13px;"><a href="//'.$site.'/watch?v='.$id.'" title="'.$judul.'">'.$judul.'</a></span><br /><span style="font-size: 11px;"><i class="fa fa-eye" aria-hidden="true" style="color: #ccc;"></i> '.$view.'<br /><i class="fa fa-calendar" aria-hidden="true" style="color: #ddd;"></i> '.$tgl.'<br /><i class="fa fa-users" aria-hidden="true" style="color: #ddd;"></i> <a href="//'.$site.'/channel?cid='.$olehid.'" title="'.$judul.'">'.$oleh.'</a></span></td></tr></tbody></table></div>
';
}else{
echo '
<div class="menu2">
<table class="otable" width="100%">
<tbody>
<tr>
<td valign="middle" width="75px" align="center">
<div class="imahe"><img src="'.$thumb.'" alt="'.$judul.'" title="'.$judul.'" style="border: 1px solid #222; border-radius: 2px; float: left;" width="95" height="60"><h8><span>channel</span></h8></div></td><td style="padding: 4px 6px 4px 6px;><span style=" font-size: 13px;"><a href="//'.$site.'/channel?cid='.$channelId.'">'.$judul.'</a></span><br /><span style="font-size: 11px;"><i class="fa fa-calendar" aria-hidden="true" style="color: #ddd;"></i> '.$tgl.'</span></td></tr></tbody></table></div>
';
}
}
}
?>