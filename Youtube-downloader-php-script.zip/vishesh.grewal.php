<?php
if(isset($_GET['q'])){
    if(stripos($_GET['q'],'youtu.be')!==false || stripos($_GET['q'],'watch?v=')!==false ){
     preg_match("/^(?:http(?:s)?:\/\/)?(?:www\.)?(?:m\.)?(?:youtu\.be\/|youtube\.com\/(?:(?:watch)?\?(?:.*&)?v(?:i)?=|(?:embed|v|vi|user)\/))([^\?&\"'>]+)/", $_GET['q'], $matches);
    $str='./watch?v='.$matches[1];
     header("Location:$str");
     exit();
     }else{
     $str='./search?q='.str_replace(' ','+', $_GET['q']);
     header("Location: $str");
     exit();
  }
}
?>