<?php
include 'inc/vishesh.function.php';

if(isset($_POST['cid']) && !empty($_POST['cid'])){
$cid = $_POST['cid'];
$token = $_POST['p'];
if(!empty($_POST['limit']) == '') {
$limit = '10';
}else{
$limit = isset($_POST['limit']) ? $_POST['limit']:'10';
}

$set = json_decode(arjo('https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&order=relevance&regionCode=id&type=videos&maxResults='.$limit.'&key='.$key.'&playlistId='.$cid.'&pageToken='.$token), true);

foreach($set[items] as $data){
$id = $data[id][videoId];
$olehid = $data[snippet][channelId];
$oleh = $data[snippet][channelTitle];
$tgl = dateyt($data[snippet][publishedAt]);
$judul = $data[snippet][title];

$dt = json_decode(arjo('https://www.googleapis.com/youtube/v3/videos?key='.$key.'&part=contentDetails,statistics&id='.$id), true);
foreach ($dt[items] as $dta) {
$watu = $dta[contentDetails][duration];
$durasi = format_timeyt($watu);
$view = number_format($dta[statistics][viewCount]);
$like = number_format($dta[statistics][likeCount]);
$galike = number_format($dta[statistics][dislikeCount]);
}
echo '
<div class="menu2">
<table class="otable" width="100%">
<tbody>
<tr>
<td valign="middle" width="75px" align="center">
<div class="imahe"><img src="//'.$site.'/ytimg/vi/'.$id.'/mqdefault.jpg" alt="'.$judul.'" title="'.$judul.'" style="border: 1px solid #222; border-radius: 2px; float: left;" width="95" height="60"><h8><span>'.$durasi.'</span></h8></div></td><td style="padding: 4px 6px 4px 6px;><span style=" font-size: 13px;"><a href="//'.$site.'/watch?v='.$id.'" title="'.$judul.'">'.$judul.'</a></span><br /><span style="font-size: 11px;"><i class="fa fa-eye" aria-hidden="true" style="color: #ccc;"></i> '.$view.'<br /><i class="fa fa-calendar" aria-hidden="true" style="color: #ddd;"></i> '.$tgl.'<br /><i class="fa fa-users" aria-hidden="true" style="color: #ddd;"></i> <a href="//'.$site.'/channel?cid='.$olehid.'" title="'.$judul.'">'.$oleh.'</a></span></td></tr></tbody></table></div>
';
}
if(!empty($set[nextPageToken])){
echo '
<div class="nav" style="text-align:center;">
<div class="show_playlist" id="'.$cid.'"></div>
<div class="loading" style="display: none;"><img src="//'.$site.'/img/load.gif"/><br>Loading...</div>
<button class="show_more" id="'.$set[nextPageToken].'" style="text-align:center;margin-top:8px;cursor:pointer;background: #e9e9e9;padding:4px;color:#555;border:1px solid grey;border-radius: 2px">Show more</button>
</div>
';
}else{
echo '
<div class="nav" style="text-align:center;">
<div class="loading" style="display: none;"><img src="//'.$site.'/img/load.gif"/><br>Loading...</div>
<button class="show_more" id="" style="text-align:center;margin-top:8px;cursor:pointer;background: #e9e9e9;padding:4px;color:#555;border:1px solid grey;border-radius: 2px">Show more Not Found!</button>
</div>
';
}}else{
echo 'Index Of';
}
?>