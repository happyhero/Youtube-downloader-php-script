<?php
include 'inc/vishesh.function.php';

$q = ucwords(str_replace('_', ' ', $_GET['q']));
$q = ucwords(str_replace('+', ' ', $q));
$q = ucwords(str_replace('%20', ' ', $q));
$token = $_GET['p'];
if(!empty($_GET['limit']) == '') {
$limit = '10';
}else{
$limit = isset($_GET['limit']) ? $_GET['limit']:'10';
}
if(!empty($_GET['q']) == '') {
   echo '<script>alert("Keywords that you wrote disabilities. or empty!");history.back();</script>';
   }
else
 {
$set = json_decode(arjo('https://www.googleapis.com/youtube/v3/search?chart=mostPopular&part=id,snippet&order=relevance&regionCode=id&q='.urlencode($q).'&type=videos&maxResults='.$limit.'&key='.$key.'&pageToken='.$token), true);
$total = $set[pageInfo][totalResults];
$title = ''.$sitename.' :: Search Results for '.ucwords($q).'';
$result = 'Search Results for '.ucwords($q).' ('.number_format($total).' Videos)';
include 'inc/vishesh.header.php';

$div = "|#|";
$dat='lastsearch.txt';

$fp=fopen($dat, 'r');
$count=fgets($fp);
fclose($fp);
$cari = $q;
$cari = str_replace('_', ' ', $cari);
$cari = str_replace('+', ' ', $cari);
$data = explode($div, $count);
if (in_array($cari, $data)) {
$tulis = implode($div, $data);
$hit=$tulis;
}
else {
$data = explode($div, $count);
$tulis = $data[1].''.$div.''.$data[2].''.$div.''.$data[3].''.$div.''.$data[4].''.$div.''.$data[5].''.$div.''.$data[6].''.$div.''.$data[7].''.$div.''.$data[8].''.$div.''.$data[9].''.$div;
$tulis .= $cari;
$hit=$tulis;
}

$masuk=fopen($dat, 'w');
fwrite($masuk,$tulis);
fclose($masuk);

echo '
<div class="biru" style="text-align: left;"><h1><i class="fa fa-th-large"></i> '.$result.'</h1></div><div class=menu align=left><div style="display:" class="breadcrumb">
<span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
<a href="/" itemprop="url"><span itemprop="title">Home</span></a></span> &#9656 <span class="active">'.ucwords($q).'</span></div></div>
';

if(!empty($total) == '0') {
echo '
<div class="menu2">
<table class="otable" width="100%">
<tbody>
<tr>
<td valign="middle" width="75px" align="center">
<div class="imahe">Error</div></td><td style="padding: 4px 6px 4px 6px;><span style=" font-size: 13px;">An error occurred: </span><span style="font-size: 11px;">sorry, not respon.</span></td></tr></tbody></table></div>
';
}else{
foreach($set[items] as $data){
$id = $data[id][videoId];
$olehid = $data[snippet][channelId];
$oleh = $data[snippet][channelTitle];
$tgl = dateyt($data[snippet][publishedAt]);
$judul = $data[snippet][title];
$thumb = $data[snippet][thumbnails][medium][url];

$dt = json_decode(arjo('https://www.googleapis.com/youtube/v3/videos?key='.$key.'&part=contentDetails,statistics&id='.$id), true);
foreach ($dt[items] as $dta) {
$watu = $dta[contentDetails][duration];
$durasi = format_timeyt($watu);
$view = number_format($dta[statistics][viewCount]);
$like = number_format($dta[statistics][likeCount]);
$galike = number_format($dta[statistics][dislikeCount]);
}
$channelId = $data[id][channelId];
if($channelId == '') {
echo '
<div class="menu2">
<table class="otable" width="100%">
<tbody>
<tr>
<td valign="middle" width="75px" align="center">
<div class="imahe"><img src="//'.$site.'/ytimg/vi/'.$id.'/mqdefault.jpg" alt="'.$judul.'" title="'.$judul.'" style="border: 1px solid #222; border-radius: 2px; float: left;" width="95" height="60"><h8><span>'.$durasi.'</span></h8></div></td><td style="padding: 4px 6px 4px 6px;><span style=" font-size: 13px;"><a href="//'.$site.'/watch?v='.$id.'" title="'.$judul.'">'.$judul.'</a></span><br /><span style="font-size: 11px;"><i class="fa fa-eye" aria-hidden="true" style="color: #ccc;"></i> '.$view.'<br /><i class="fa fa-calendar" aria-hidden="true" style="color: #ddd;"></i> '.$tgl.'<br /><i class="fa fa-users" aria-hidden="true" style="color: #ddd;"></i> <a href="//'.$site.'/channel?cid='.$olehid.'" title="'.$judul.'">'.$oleh.'</a></span></td></tr></tbody></table></div>
';
}else{
echo '
<div class="menu2">
<table class="otable" width="100%">
<tbody>
<tr>
<td valign="middle" width="75px" align="center">
<div class="imahe"><img src="'.$thumb.'" alt="'.$judul.'" title="'.$judul.'" style="border: 1px solid #222; border-radius: 2px; float: left;" width="95" height="60"><h8><span>channel</span></h8></div></td><td style="padding: 4px 6px 4px 6px;><span style=" font-size: 13px;"><a href="//'.$site.'/channel?cid='.$channelId.'">'.$judul.'</a></span><br /><span style="font-size: 11px;"><i class="fa fa-calendar" aria-hidden="true" style="color: #ddd;"></i> '.$tgl.'</span></td></tr></tbody></table></div>
';
}
}
echo '
<div class="result"></div>
<div class="nav" style="text-align:center;">
<div class="show_search" id="'.$q.'"></div>
<div class="loading" style="display: none;"><img src="//'.$site.'/img/load.gif"/><br>Loading...</div>
<button class="show_more" id="'.$set[nextPageToken].'" style="text-align:center;margin-top:8px;cursor:pointer;background: #e9e9e9;padding:4px;color:#555;border:1px solid grey;border-radius: 2px">Show more</button>
</div>
';?>
<script type="text/javascript">
$(document).ready(function(){
$(document).on('click','.show_more',function(){
var Q = $('.show_search').attr('id');
var P = $('.show_more').attr('id');
$('.show_more').hide();
$('.loading').show();

$.ajax({	 type:'POST',	 url:'sajax.php', data:'q='+Q+'&p='+P,	 success:function(html){
$('.nav').remove();
$('#'+P).remove();
$('.loading').remove();
$('.result').append(html);
}
});	});});
</script>
</div>
<?php
}
include 'inc/vishesh.footer.php';
}

?>