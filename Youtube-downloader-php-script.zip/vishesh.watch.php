;
<?php
$id = $_GET['v'];
include 'inc/vishesh.function.php';

$set = json_decode(arjo('https://www.googleapis.com/youtube/v3/videos?alt=json&part=id,snippet,contentDetails,statistics,topicDetails&id='.$id.'&type=videos&key='.$key), true);
$name = $set[items][0][snippet][title];
$olehid = $set[items][0][snippet][channelId];
$oleh = $set[items][0][snippet][channelTitle];
$total = $set[pageInfo][totalResults];
if($_GET['v'] == '') {
$title = ':: '.$sitename.' :: Error Not VideoID';
$result = 'Error Not VideoID';
}
else if(!empty($total) == '0') {
$title = ':: '.$sitename.' :: Error VideoID';
$result = 'Error VideoID';
} else {
$title = ''.$sitename.' :: Your watch '.ucwords($name).'';
$result = 'Your watch '.ucwords($name).'';
}
include 'inc/vishesh.header.php';


echo '<script type="text/javascript" src="http://wap4dollar.com/ad/codex/?id=pkfenmxmgz"></script>
<div class="vheader" style="text-align: center;"><h1>'.$result.'</h1></div><div class=menu align=left><div style="display:" class="breadcrumb">
<span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
<a href="/" itemprop="url"><span itemprop="title">Home</span></a></span> &#9656 <span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="//'.$site.'/channel?cid='.$olehid.'" itemprop="url">'.$oleh.'</a></span>
&#9656; <span class="active">'.ucwords($name).'</span></div></div>
';

if($_GET['v'] == '') {
echo '
<div class="menu2">
<table class="otable" width="100%">
<tbody>
<tr>
<td valign="middle" width="75px" align="center">
<div class="imahe">Error</div></td><td style="padding: 4px 6px 4px 6px;><span style=" font-size: 13px;">An error occurred: </span><span style="font-size: 11px;">sorry, id not found.</span></td></tr></tbody></table></div>
';
}
else if(!empty($total) == '0') {
echo '
<div class="menu2">
<table class="otable" width="100%">
<tbody>
<tr>
<td valign="middle" width="75px" align="center">
<div class="imahe">Error</div></td><td style="padding: 4px 6px 4px 6px;><span style=" font-size: 13px;">An error occurred: </span><span style="font-size: 11px;">sorry, error id.</span></td></tr></tbody></table></div>
';
}else{
foreach($set[items] as $data){
$id = $data[id];
$olehid = $data[snippet][channelId];
$oleh = $data[snippet][channelTitle];
$tgl = dateyt($data[snippet][publishedAt]);
$judul = $data[snippet][title];
$descript = $data[snippet][description];
$watu = $data[contentDetails][duration];
$durasi = timeyt($watu);
$view = number_format($data[statistics][viewCount]);
$like = number_format($data[statistics][likeCount]);
$galike = number_format($data[statistics][dislikeCount]);
$tags = $data[snippet][tags];
$ctid = $data[snippet][categoryId];

echo '
<div class="menu2" style="margin-bottom:0px; text-align: center; background-color: #303030;">
<table style="width:100%;text-align:center;"><tbody style="max-height:100%;"><tr valign="top"><td width="100%"><iframe height="100%" width="100%" src="//www.youtube.com/embed/'.$id.'?html5=1&enablejsapi=1&autoplay=0&hd=1&rel=0&showinfo=0&modestbranding=1&iv_load_policy=3&autohide=1&start=0&theme=light&vq=480p&wmode=transparent" frameborder="0" allowfullscreen></iframe></td></tr></tbody></table>
</div>
<div class="menu" style="text-align: center;"> <img src="//'.$site.'/ytimg/vi/'.$id.'/1.jpg" alt="'.$judul.'" style="border:2px solid #282828;" width="100px"><img src="//'.$site.'/ytimg/vi/'.$id.'/2.jpg" alt="'.$judul.'" style="border:2px solid #282828;" width="100px">
<img src="//'.$site.'/ytimg/vi/'.$id.'/3.jpg" alt="'.$judul.'" style="border:2px solid #282828;" width="100px">
</div>

<script type="text/javascript" src="http://wap4dollar.com/ad/code/?id=pkfenmxmgz"></script>
<div class="menu2"><div class="ml"><table class="otable" style="width:100%"><tbody><tr valign="top"> <td width="30%"> Title</td><td> :</td> <td>'.$judul.'</td></tr>
<tr valign="top"><td width="30%"> Duration</td><td> : </td> <td> '.$durasi.' </td></tr>
<tr valign="top"><td width="30%"> Views</td><td> : </td> <td> '.$view.'</td></tr>
<tr valign="top"><td width="30%"> Likes</td><td> : </td> <td> <span style="color:green">'.$like.'</span></td></tr>
<tr valign="top"><td width="30%"> Dislikes</td><td> : </td> <td> <span style="color:red">'.$galike.'</span></td></tr>
<tr valign="top"><td width="30%">Published At</td><td> : </td> <td> '.$tgl.'</td></tr>
<tr valign="top"><td width="30%">Uploaded By</td><td> : </td> <td> <a href="//'.$site.'/channel?cid='.$olehid.'">'.$oleh.'</a></td></tr>
<tr valign="top"><td width="30%">Description</td><td> : </td> <td> ';
if($_GET['more'] == 'full'){
echo str_replace(urldecode('%0A'), '<br />', $descript);
}elseif($descript == ''){
echo "0";
}elseif(strlen($descript)>37){
echo ''.substr(str_replace(urldecode('%0A'), '<br />', $descript),0,37).'... (<a href=\'//'.$site.'/watch?v='.$id.'&more=full\'> More Description </a>)';
}elseif(strlen($descript)>5){
echo ''.str_replace(urldecode('%0A'), '<br />', $descript).'';
}
echo ' </td></tr>
';
if($tags == ''){
echo '';
}else{
foreach($tags as $tagz){
$t[] = "<a href='//$site/vishesh.php?q=".str_replace(' ','+', $tagz)."'>$tagz</a>";
}
echo '
<tr valign="top"><td width="30%"> Tags</td><td> : </td> <td> ';echo implode(', ',$t); echo ' </td></tr>
';
}
echo '
</tbody></table></div></div>
</div>
';
echo '
<div class="biru2"><h2><i class="fa fa-download" aria-hidden="true"></i> Download Video or Audio</h2></div><div class="menu2"></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/iframe-resizer/3.5.14/iframeResizer.min.js"></script>
<script type="text/javascript" src="http://wap4dollar.com/ad/codex/?id=pkfenmxmgz"></script>
<script type="text/javascript" src="http://wap4dollar.com/ad/code/?id=pkfenmxmgz"></script>
<script>iFrameResize({}, \'.button-api-frame\');</script>
<iframe src="https://youtubemp3api.com/@api/button/videos/'.$id.'" style="width:100%;border:0;height:206px;" scrolling="no"></iframe><iframe src="https://youtubemp3api.com/@api/button/mp3/'.$id.'" style="width:100%;height:200px;border:0;" scrolling="no"></iframe>';
}}
if(!empty($total) == '0') {
echo ''; }else{
include 'vishesh.related.php';
}

include 'inc/vishesh.footer.php';

?>